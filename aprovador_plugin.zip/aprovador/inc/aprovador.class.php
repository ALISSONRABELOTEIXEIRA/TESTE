<?php

class PluginAprovadorAprovador extends CommonDBTM {

    static function getTypeName($nb = 0) {
        return _n('Aprovador', 'Aprovadores', $nb);
    }

    function canCreate() {
        return Session::haveRight("config", UPDATE);
    }

    function canView() {
        return Session::haveRight("config", READ);
    }

    function canCancel() {
        return Session::haveRight("config", UPDATE);
    }

    function canPurge() {
        return Session::haveRight("config", UPDATE);
    }
}
