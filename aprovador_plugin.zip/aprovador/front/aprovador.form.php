<?php
include ('../../../inc/includes.php');

Session::checkRight("config", READ);

Html::header('Aprovador', $_SERVER['PHP_SELF'], "plugins");

echo "<h1>Bem-vindo ao Plugin Aprovador</h1>";

Html::footer();
