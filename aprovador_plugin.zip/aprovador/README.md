# Plugin Aprovador para GLPI
Plugin para adicionar um campo de e-mail de aprovador nos chamados do GLPI.
