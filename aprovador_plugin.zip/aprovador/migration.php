<?php
function plugin_aprovador_install() {
    global $DB;

    $query = "CREATE TABLE IF NOT EXISTS `glpi_plugin_aprovador_tickets` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `tickets_id` int(11) NOT NULL,
                `aprovador_email` varchar(255) DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `tickets_id` (`tickets_id`)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $DB->queryOrDie($query, "Erro ao criar a tabela de aprovadores.");

    return true;
}

function plugin_aprovador_uninstall() {
    global $DB;

    $DB->queryOrDie("DROP TABLE IF EXISTS `glpi_plugin_aprovador_tickets`", "Erro ao excluir a tabela.");

    return true;
}
