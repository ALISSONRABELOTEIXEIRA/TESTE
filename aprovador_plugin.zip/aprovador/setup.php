<?php

function plugin_init_aprovador() {
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['aprovador'] = true;
    $PLUGIN_HOOKS['add_css']['aprovador'] = 'css/style.css';
    $PLUGIN_HOOKS['menu_toadd']['aprovador'] = [
        'plugins' => 'front/aprovador.form.php'
    ];
}

function plugin_version_aprovador() {
    return [
        'name'           => 'Aprovador',
        'version'        => '1.0.0',
        'author'         => 'Alisson Teixeira',
        'license'        => 'GPLv3',
        'homepage'       => 'https://seudominio.com',
        'minGlpiVersion' => '10.0.0'
    ];
}

function plugin_aprovador_check_prerequisites() {
    return version_compare(GLPI_VERSION, '10.0.0', '>=');
}

function plugin_aprovador_check_config() {
    return true;
}
