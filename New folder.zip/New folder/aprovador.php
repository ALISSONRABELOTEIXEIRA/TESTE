<?php
// File: plugins/aprovador/plugin.php

if (!defined('GLPI_ROOT')) {
   die("Sorry. You can't access directly to this file");
}

define('PLUGIN_APROVADOR_VERSION', '1.0.0');

/**
 * Plugin metadata
 */
function plugin_version_aprovador() {
   return [
       'name'           => 'Aprovador',
       'version'        => PLUGIN_APROVADOR_VERSION,
       'author'         => 'Alisson Teixeira',
       'license'        => 'GPLv2+',
       'minGlpiVersion' => '9.5'
   ];
}

/**
 * Initialize plugin: register hooks
 */
function plugin_init_aprovador() {
   global $PLUGIN_HOOKS;
   // Add field to ticket form
   $PLUGIN_HOOKS['pre_item_form']['aprovador'] = ['Ticket' => 'plugin_aprovador_add_field'];
   // Save field on ticket add/update
   $PLUGIN_HOOKS['post_item_add']['aprovador']    = ['Ticket' => 'plugin_aprovador_save_field'];
   $PLUGIN_HOOKS['post_item_update']['aprovador'] = ['Ticket' => 'plugin_aprovador_save_field'];
}

/**
 * Installation: create table to store aprovador email
 */
function plugin_aprovador_install() {
   global $DB;
   // Create table if not exists
   if (!$DB->tableExists('glpi_plugin_aprovador')) {
       $DB->query("""
           CREATE TABLE `glpi_plugin_aprovador` (
               `items_id` INT(11)      NOT NULL,
               `itemtype` VARCHAR(45) NOT NULL,
               `aprovador` VARCHAR(255) DEFAULT NULL,
               PRIMARY KEY (`items_id`, `itemtype`)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
       """);
   }
   return true;
}

/**
 * Uninstallation: drop plugin table
 */
function plugin_aprovador_uninstall() {
   global $DB;
   $DB->query("DROP TABLE IF EXISTS `glpi_plugin_aprovador`;");
   return true;
}
